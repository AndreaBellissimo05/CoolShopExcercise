﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoolShop
{
    public class Order
    {
        // Fields that describe an order
        public int Id;
        public string ArticleName;
        public int Quantity;
        public float UnitPrice;
        public float PercentageDiscount;
        public string Buyer;

        // Method to print the order as a string
        public override string ToString()
        {
            return $"Id: {Id}, Article Name: {ArticleName}, Quantity: {Quantity}, Price: {UnitPrice}€, Discount: {PercentageDiscount}%, Buyer: {Buyer}";
        }

        // Static method: find the order with the highest quantity
        public static Order GetOrderWithMaxQuantity(List<Order> orders)
        {
            Order maxOrder = null;
            int maxQuantity = int.MinValue;

            foreach (var order in orders)
            {
                if (order.Quantity > maxQuantity)
                {
                    maxQuantity = order.Quantity;
                    maxOrder = order;
                }
            }

            return maxOrder;
        }

        // Static method: find the order with the biggest total amount (quantity * price)
        public static Order GetBiggestImport(List<Order> orders)
        {
            Order biggestOrder = null;
            float maxImport = float.MinValue;

            foreach (var order in orders)
            {
                float total = order.Quantity * order.UnitPrice;
                if (total > maxImport)
                {
                    maxImport = total;
                    biggestOrder = order;
                }
            }

            return biggestOrder;
        }

        // Static method: find the order with the biggest discount difference
        public static Order GetOrderWithMaxDiscountDifference(List<Order> orders)
        {
            Order maxOrder = null;
            float maxDifference = float.MinValue;

            foreach (var order in orders)
            {
                // Difference = total amount * (discount percentage / 100)
                float difference = order.Quantity * order.UnitPrice * (order.PercentageDiscount / 100);
                if (difference > maxDifference)
                {
                    maxDifference = difference;
                    maxOrder = order;
                }
            }

            return maxOrder;
        }
    }

}

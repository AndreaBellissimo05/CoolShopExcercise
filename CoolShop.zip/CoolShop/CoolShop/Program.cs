﻿/* This program reads a CSV file with order data,
    creates a list of Order objects, prints them, and finds some specific results (max quantity, biggest total, etc.)
*/

using System.Globalization;

namespace CoolShop
{
    class Program
    {
        static void Main()
        {
            string pathFile = "orderList.csv";

            // Check if the file exists
            if (!File.Exists(pathFile))
            {
                Console.WriteLine($"Error: the file \"{pathFile}\" does not exist.");
                return;
            }

            // Read all lines from the CSV file
            string[] rows = File.ReadAllLines(pathFile);

            List<Order> orders = new List<Order>();

            // Read the CSV and create Order objects
            for (int i = 1; i < rows.Length; i++) // skip header row
            {
                if (string.IsNullOrWhiteSpace(rows[i])) continue; // skip empty lines

                string[] columns = rows[i].Split(';');
                if (columns.Length < 6) continue; // skip invalid lines

                // Create a new order from CSV row
                Order order = new Order
                {
                    Id = int.Parse(columns[0].Trim()),
                    ArticleName = columns[1].Trim(),
                    Quantity = int.Parse(columns[2].Trim()),
                    UnitPrice = float.Parse(columns[3].Trim(), CultureInfo.InvariantCulture),
                    PercentageDiscount = float.Parse(columns[4].Trim(), CultureInfo.InvariantCulture),
                    Buyer = columns[5].Trim()
                };

                orders.Add(order); // add order to the list
            }

            // Print all orders
            Console.WriteLine("All orders:");
            foreach (var order in orders)
            {
                Console.WriteLine(order);
            }

            // Find the order with the highest quantity
            Order maxQuantityOrder = Order.GetOrderWithMaxQuantity(orders);
            if (maxQuantityOrder != null)
            {
                Console.WriteLine("\nOrder with the highest quantity:");
                Console.WriteLine(maxQuantityOrder);
            }

            // Find the order with the biggest total amount
            Order biggestImportOrder = Order.GetBiggestImport(orders);
            if (biggestImportOrder != null)
            {
                Console.WriteLine("\nOrder with the biggest total amount:");
                Console.WriteLine($"Order: {biggestImportOrder} - Total Amount: {biggestImportOrder.Quantity * biggestImportOrder.UnitPrice}€");
            }

            // Find the order with the biggest discount difference
            Order maxDiscountDifference = Order.GetOrderWithMaxDiscountDifference(orders);
            if (maxDiscountDifference != null)
            {
                Console.WriteLine("\nOrder with the biggest difference between total without discount and total with discount:");
                Console.WriteLine(maxDiscountDifference);
            }
        }
    }
}